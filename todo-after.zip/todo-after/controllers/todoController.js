const Todo = require('../models/todoModel');

exports.getTodos = (req, res) => {
    Todo.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

exports.createTodo = (req, res) => {
    const { task } = req.body;
    Todo.create(task, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Task added' });
    });
};
